db_host='database-1.csxkpwy7xzho.us-east-1.rds.amazonaws.com'
db_username="sqldeveloper"
db_password="pa55word"
db_name="Mortality"
